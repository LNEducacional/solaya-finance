# SOLAYA • Sistema Financeiro (MVP)

React + Vite + Tailwind. Persistência localStorage.

## Como rodar
1) Instale Node 18+
2) `npm install`
3) `npm run dev`
4) Abrir http://localhost:5173

## Build de produção
- `npm run build` gera a pasta `dist/`

## Deploy rápido
- **Vercel**: importe o repositório, Framework = Vite, `build` e `dist/`
- **Netlify**: build = `npm run build`, publish = `dist`
- **HostGator/cPanel**: faça o build e envie o conteúdo de `dist/` para `public_html/` (ou subpasta).

## Dependências principais
- Tailwind, Recharts, Framer Motion, Lucide React
