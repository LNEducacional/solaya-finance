import React, { useEffect, useMemo, useReducer, useState } from "react";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Plus, Pencil, Trash2, Upload, Download, FolderOpen, Wallet, Users, Factory, TrendingUp, TrendingDown, Repeat, Settings, BarChart3, ClipboardList, ChevronRight, Search } from "lucide-react";

/*************************************
 * SOLAYA — Sistema Financeiro (MVP)
 * Single-file React App (Tailwind + shadcn/ui style)
 * Persistência: localStorage
 * Escopo: Entradas, Saídas, Investimentos, Gastos Fixos, Fornecedores, Colaboradores,
 *         Categorias, Contas/Carteiras, Relatórios (DRE/Fluxo de Caixa), Import/Export
 *************************************/

/***** UTIL *****/
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
const BRL = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
const fmtDate = (d) => new Date(d).toISOString().slice(0, 10);
const today = () => fmtDate(new Date());

function useLocalStorage(key, initialValue) {
  const [state, setState] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
  return [state, setState];
}

/***** DATA MODEL *****/
const initialDB = {
  version: 1,
  company: { name: "SOLAYA", cnpj: "", regime: "Simples" },
  accounts: [
    { id: "acc_caixa", name: "Caixa", type: "caixa" },
    { id: "acc_bb", name: "Banco do Brasil", type: "bancaria" },
    { id: "acc_cc", name: "Cartão Crédito", type: "cartao" },
  ],
  categories: [
    { id: "cat_venda", name: "Vendas", kind: "entrada" },
    { id: "cat_frete", name: "Frete", kind: "saida" },
    { id: "cat_mkt", name: "Marketing", kind: "saida" },
    { id: "cat_insumo", name: "Insumos", kind: "saida" },
    { id: "cat_salario", name: "Salários", kind: "saida" },
    { id: "cat_invest", name: "Aporte/Invest", kind: "investimento" },
  ],
  collaborators: [],
  suppliers: [],
  fixedExpenses: [
    // { id, name, day, amount, accountId, categoryId, active }
  ],
  investments: [
    // { id, date, name, amount, categoryId, accountId, notes }
  ],
  transactions: [
    // { id, date, type, amount, categoryId, accountId, description, collaboratorId, supplierId, paymentMethod, status }
  ],
};

/***** REDUCER *****/
function reducer(state, action) {
  switch (action.type) {
    case "LOAD":
      return action.payload;
    case "RESET":
      return initialDB;
    case "UPSERT_ITEM": {
      const { collection, item } = action;
      const arr = [...state[collection]];
      const idx = arr.findIndex((x) => x.id === item.id);
      if (idx >= 0) arr[idx] = item; else arr.push(item);
      return { ...state, [collection]: arr };
    }
    case "DELETE_ITEM": {
      const { collection, id } = action;
      return { ...state, [collection]: state[collection].filter((x) => x.id !== id) };
    }
    case "BULK_INSERT": {
      const { collection, items } = action;
      return { ...state, [collection]: [...state[collection], ...items] };
    }
    default:
      return state;
  }
}

/***** STORE WRAPPER *****/
function useDB() {
  const [persisted, setPersisted] = useLocalStorage("solaya_fin_db", initialDB);
  const [state, dispatch] = useReducer(reducer, persisted);
  useEffect(() => setPersisted(state), [state]);
  return { state, dispatch };
}

/***** SHARED UI *****/
function Section({ title, icon, children, actions }) {
  return (
    <div className="bg-white/70 backdrop-blur rounded-2xl shadow p-5 border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {icon}
          <h2 className="text-xl font-semibold">{title}</h2>
        </div>
        <div className="flex gap-2">{actions}</div>
      </div>
      {children}
    </div>
  );
}

function Button({ children, onClick, variant = "primary", type = "button" }) {
  const base = "px-3 py-2 rounded-xl text-sm font-medium shadow-sm";
  const map = {
    primary: "bg-black text-white hover:bg-gray-900",
    ghost: "bg-transparent hover:bg-gray-100",
    outline: "border border-gray-300 hover:bg-gray-50",
    danger: "bg-red-600 text-white hover:bg-red-700",
  };
  return (
    <button type={type} onClick={onClick} className={`${base} ${map[variant]}`}>
      {children}
    </button>
  );
}

function Input({ label, ...props }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="text-gray-600">{label}</span>
      <input {...props} className="border rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-black/20" />
    </label>
  );
}

function Select({ label, children, ...props }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="text-gray-600">{label}</span>
      <select {...props} className="border rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-black/20">
        {children}
      </select>
    </label>
  );
}

function Currency({ value }) {
  return <span>{BRL.format(Number(value || 0))}</span>;
}

/***** FORMS *****/
function TransactionForm({ db, onSave, edit }) {
  const [form, setForm] = useState(
    edit || {
      id: uid(),
      date: today(),
      type: "entrada",
      amount: 0,
      categoryId: db.categories.find((c) => c.kind === "entrada")?.id || "",
      accountId: db.accounts[0]?.id || "",
      description: "",
      collaboratorId: "",
      supplierId: "",
      paymentMethod: "pix",
      status: "confirmado",
    }
  );

  const onChange = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSave(form);
      }}
      className="grid md:grid-cols-4 gap-3"
    >
      <Select label="Tipo" value={form.type} onChange={(e) => onChange("type", e.target.value)}>
        <option value="entrada">Entrada (Venda)</option>
        <option value="saida">Saída (Despesa)</option>
        <option value="investimento">Investimento</option>
      </Select>
      <Input label="Data" type="date" value={form.date} onChange={(e) => onChange("date", e.target.value)} />
      <Input label="Valor (R$)" type="number" step="0.01" value={form.amount} onChange={(e) => onChange("amount", e.target.value)} />
      <Select label="Conta" value={form.accountId} onChange={(e) => onChange("accountId", e.target.value)}>
        {db.accounts.map((a) => (
          <option key={a.id} value={a.id}>{a.name}</option>
        ))}
      </Select>
      <Select label="Categoria" value={form.categoryId} onChange={(e) => onChange("categoryId", e.target.value)}>
        {db.categories
          .filter((c) => (form.type === "entrada" ? c.kind === "entrada" : form.type === "saida" ? c.kind === "saida" : c.kind === "investimento"))
          .map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
      </Select>
      <Input label="Descrição" value={form.description} onChange={(e) => onChange("description", e.target.value)} />
      <Select label="Colaborador" value={form.collaboratorId} onChange={(e) => onChange("collaboratorId", e.target.value)}>
        <option value="">—</option>
        {db.collaborators.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </Select>
      <Select label="Fornecedor" value={form.supplierId} onChange={(e) => onChange("supplierId", e.target.value)}>
        <option value="">—</option>
        {db.suppliers.map((s) => (
          <option key={s.id} value={s.id}>{s.name}</option>
        ))}
      </Select>
      <Select label="Pagamento" value={form.paymentMethod} onChange={(e) => onChange("paymentMethod", e.target.value)}>
        <option value="pix">PIX</option>
        <option value="cartao">Cartão</option>
        <option value="boleto">Boleto</option>
        <option value="dinheiro">Dinheiro</option>
      </Select>
      <Select label="Status" value={form.status} onChange={(e) => onChange("status", e.target.value)}>
        <option value="confirmado">Confirmado</option>
        <option value="pendente">Pendente</option>
        <option value="cancelado">Cancelado</option>
      </Select>
      <div className="md:col-span-4 flex justify-end gap-2 mt-2">
        <Button variant="outline" onClick={() => onSave(null)}>Cancelar</Button>
        <Button type="submit"><span className="inline-flex items-center gap-2"><Plus size={16}/>Salvar</span></Button>
      </div>
    </form>
  );
}

function SimpleForm({ schema, initial, onSave }) {
  const [form, setForm] = useState(initial);
  const onChange = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); onSave(form); }}
      className="grid md:grid-cols-3 gap-3"
    >
      {schema.map((field) => field.type === "select" ? (
        <Select key={field.key} label={field.label} value={form[field.key]} onChange={(e) => onChange(field.key, e.target.value)}>
          {field.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
      ) : (
        <Input key={field.key} label={field.label} type={field.inputType || "text"} value={form[field.key]} onChange={(e) => onChange(field.key, e.target.value)} />
      ))}
      <div className="md:col-span-3 flex justify-end gap-2 mt-2">
        <Button variant="outline" onClick={() => onSave(null)}>Cancelar</Button>
        <Button type="submit">Salvar</Button>
      </div>
    </form>
  );
}

/***** TABLE *****/
function Table({ columns, rows, onEdit, onDelete, filterText }) {
  const filtered = useMemo(() => {
    if (!filterText) return rows;
    const q = filterText.toLowerCase();
    return rows.filter((r) => Object.values(r).some((v) => String(v || "").toLowerCase().includes(q)));
  }, [rows, filterText]);

  return (
    <div className="overflow-auto border rounded-2xl">
      <table className="min-w-full text-sm">
        <thead className="bg-gray-50">
          <tr>
            {columns.map((c) => <th key={c.key} className="text-left px-3 py-2 font-medium text-gray-600 whitespace-nowrap">{c.label}</th>)}
            <th className="px-3 py-2"/>
          </tr>
        </thead>
        <tbody>
          {filtered.map((r) => (
            <tr key={r.id} className="border-t">
              {columns.map((c) => (
                <td key={c.key} className="px-3 py-2 whitespace-nowrap">{c.render ? c.render(r[c.key], r) : String(r[c.key] ?? "")}</td>
              ))}
              <td className="px-3 py-2">
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => onEdit(r)}><Pencil size={14}/></Button>
                  <Button variant="danger" onClick={() => onDelete(r)}><Trash2 size={14}/></Button>
                </div>
              </td>
            </tr>
          ))}
          {filtered.length === 0 && (
            <tr>
              <td className="px-3 py-8 text-center text-gray-500" colSpan={columns.length + 1}>Sem registros</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

/***** MODULES *****/
function Dashboard({ db }) {
  const month = new Date().toISOString().slice(0,7);
  const txMonth = db.transactions.filter(t => t.date.slice(0,7) === month && t.status !== "cancelado");
  const entradas = txMonth.filter(t=>t.type==="entrada").reduce((s,t)=>s+Number(t.amount),0);
  const saidas = txMonth.filter(t=>t.type==="saida").reduce((s,t)=>s+Number(t.amount),0);
  const invest = txMonth.filter(t=>t.type==="investimento").reduce((s,t)=>s+Number(t.amount),0);
  const saldo = entradas - saidas;

  // cashflow 12m
  const months = [...Array(12)].map((_,i)=>{
    const d = new Date(); d.setMonth(d.getMonth()- (11-i));
    const key = d.toISOString().slice(0,7);
    const tx = db.transactions.filter(t=>t.date.slice(0,7)===key && t.status!=="cancelado");
    const e = tx.filter(t=>t.type==="entrada").reduce((s,t)=>s+Number(t.amount),0);
    const s = tx.filter(t=>t.type==="saida").reduce((s,t)=>s+Number(t.amount),0);
    return { name: key, entradas: e, saidas: s, saldo: e-s };
  });

  const byCat = useMemo(()=>{
    const map = new Map();
    db.transactions.filter(t=>t.type==="saida" && t.status!=="cancelado").forEach(t=>{
      const cat = db.categories.find(c=>c.id===t.categoryId)?.name || "Outros";
      map.set(cat, (map.get(cat)||0)+Number(t.amount));
    });
    return [...map.entries()].map(([name,value])=>({ name, value }));
  },[db]);

  return (
    <div className="grid xl:grid-cols-3 gap-5">
      <div className="xl:col-span-2 grid sm:grid-cols-4 gap-3">
        <KPI icon={<TrendingUp size={18}/>} label="Entradas (mês)" value={BRL.format(entradas)} />
        <KPI icon={<TrendingDown size={18}/>} label="Saídas (mês)" value={BRL.format(saidas)} />
        <KPI icon={<Wallet size={18}/>} label="Saldo (mês)" value={BRL.format(saldo)} />
        <KPI icon={<Repeat size={18}/>} label="Investimentos (mês)" value={BRL.format(invest)} />
        <Section title="Fluxo de Caixa (12m)" icon={<BarChart3 size={18}/>}>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={months} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
                <XAxis dataKey="name" fontSize={12}/>
                <YAxis fontSize={12}/>
                <Tooltip formatter={(v)=>BRL.format(v)} />
                <Area type="monotone" dataKey="entradas" stackId="1" fillOpacity={0.3} strokeOpacity={0.8} />
                <Area type="monotone" dataKey="saidas" stackId="1" fillOpacity={0.3} strokeOpacity={0.8} />
                <Area type="monotone" dataKey="saldo" fillOpacity={0.3} strokeOpacity={0.8} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Section>
      </div>
      <Section title="Despesas por Categoria" icon={<ClipboardList size={18}/> }>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={byCat} dataKey="value" nameKey="name" outerRadius={100}>
                {byCat.map((_, i) => <Cell key={i} />)}
              </Pie>
              <Tooltip formatter={(v)=>BRL.format(v)} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-2 gap-2 text-sm">
          {byCat.map((c,i)=> (
            <div key={i} className="flex items-center justify-between border rounded-xl px-3 py-2">
              <span>{c.name}</span>
              <strong>{BRL.format(c.value)}</strong>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

function KPI({ icon, label, value }) {
  return (
    <div className="bg-white/80 border border-gray-100 rounded-2xl p-4 shadow flex items-center justify-between">
      <div className="flex items-center gap-2 text-gray-600">{icon}<span className="text-sm">{label}</span></div>
      <div className="text-lg font-semibold">{value}</div>
    </div>
  );
}

function TransactionsModule({ db, dispatch }) {
  const [editing, setEditing] = useState(null);
  const [query, setQuery] = useState("");

  const onSave = (item) => {
    setEditing(null);
    if (!item) return;
    dispatch({ type: "UPSERT_ITEM", collection: "transactions", item });
  };
  const onDelete = (r) => dispatch({ type: "DELETE_ITEM", collection: "transactions", id: r.id });

  const columns = [
    { key: "date", label: "Data" },
    { key: "type", label: "Tipo", render: (v)=> ({entrada:"Entrada",saida:"Saída",investimento:"Invest."}[v]||v) },
    { key: "amount", label: "Valor", render: (v)=> <Currency value={v}/> },
    { key: "categoryId", label: "Categoria", render: (v)=> db.categories.find(c=>c.id===v)?.name || "-" },
    { key: "accountId", label: "Conta", render: (v)=> db.accounts.find(a=>a.id===v)?.name || "-" },
    { key: "description", label: "Descrição" },
    { key: "collaboratorId", label: "Colaborador", render: (v)=> db.collaborators.find(c=>c.id===v)?.name || "-" },
    { key: "supplierId", label: "Fornecedor", render: (v)=> db.suppliers.find(s=>s.id===v)?.name || "-" },
    { key: "status", label: "Status" },
  ];

  return (
    <Section
      title="Lançamentos (Entradas, Saídas, Investimentos)"
      icon={<FolderOpen size={18}/>} 
      actions={
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5" size={16}/>
            <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Buscar..." className="pl-7 pr-3 py-2 border rounded-xl"/>
          </div>
          <Button onClick={()=> setEditing({})}><Plus size={16}/> Novo</Button>
        </div>
      }
    >
      {editing ? (
        <TransactionForm db={db} edit={editing.id? editing: undefined} onSave={onSave} />
      ) : null}
      <div className="mt-4">
        <Table columns={columns} rows={[...db.transactions].sort((a,b)=> b.date.localeCompare(a.date))} onEdit={setEditing} onDelete={onDelete} filterText={query}/>
      </div>
    </Section>
  );
}

function SimpleModule({ title, collection, icon, fields, db, dispatch }) {
  const [editing, setEditing] = useState(null);
  const [query, setQuery] = useState("");

  const columns = fields.map((f)=> ({ key: f.key, label: f.label }));

  return (
    <Section title={title} icon={icon} actions={
      <div className="flex gap-2 items-center">
        <div className="relative">
          <Search className="absolute left-2 top-2.5" size={16}/>
          <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Buscar..." className="pl-7 pr-3 py-2 border rounded-xl"/>
        </div>
        <Button onClick={()=> setEditing({ id: uid() })}><Plus size={16}/> Novo</Button>
      </div>
    }>
      {editing ? (
        <SimpleForm
          schema={fields}
          initial={fields.reduce((acc,f)=> ({ ...acc, [f.key]: editing[f.key] || (f.default ?? "") }), { id: editing.id || uid() })}
          onSave={(item)=>{ setEditing(null); if (item) dispatch({ type: "UPSERT_ITEM", collection, item }); }}
        />
      ) : null}
      <div className="mt-4">
        <Table
          columns={columns}
          rows={db[collection].map((r)=> ({ ...r }))}
          onEdit={setEditing}
          onDelete={(r)=> dispatch({ type: "DELETE_ITEM", collection, id: r.id })}
          filterText={query}
        />
      </div>
    </Section>
  );
}

/***** RELATÓRIOS *****/
function Reports({ db }) {
  const [from, setFrom] = useState(new Date(new Date().getFullYear(), 0, 1).toISOString().slice(0,10));
  const [to, setTo] = useState(today());

  const tx = useMemo(()=> db.transactions.filter(t=> t.date>=from && t.date<=to && t.status!=="cancelado"), [db, from, to]);
  const receita = tx.filter(t=>t.type==="entrada").reduce((s,t)=>s+Number(t.amount),0);
  const custos = tx.filter(t=>t.type==="saida" && db.categories.find(c=>c.id===t.categoryId)?.name.toLowerCase().includes("insumo")).reduce((s,t)=>s+Number(t.amount),0);
  const despesas = tx.filter(t=>t.type==="saida" && !db.categories.find(c=>c.id===t.categoryId)?.name.toLowerCase().includes("insumo")).reduce((s,t)=>s+Number(t.amount),0);
  const lucroBruto = receita - custos;
  const lucroOperacional = lucroBruto - despesas;

  const porMes = useMemo(()=>{
    const map = new Map();
    tx.forEach(t=>{
      const k = t.date.slice(0,7);
      const val = Number(t.amount);
      const cur = map.get(k) || { receita:0, saida:0 };
      if (t.type === "entrada") cur.receita += val; else cur.saida += val;
      map.set(k, cur);
    });
    return [...map.entries()].sort((a,b)=> a[0].localeCompare(b[0])).map(([m,v])=> ({ mes:m, receita:v.receita, saida:v.saida, saldo: v.receita - v.saida }));
  },[tx]);

  return (
    <Section title="Relatórios" icon={<BarChart3 size={18}/> }>
      <div className="grid md:grid-cols-6 gap-3 mb-4">
        <Input label="De" type="date" value={from} onChange={(e)=>setFrom(e.target.value)} />
        <Input label="Até" type="date" value={to} onChange={(e)=>setTo(e.target.value)} />
        <div className="md:col-span-2 bg-gray-50 rounded-2xl p-3 flex items-center justify-between">
          <span>Receita</span><strong>{BRL.format(receita)}</strong>
        </div>
        <div className="bg-gray-50 rounded-2xl p-3 flex items-center justify-between">
          <span>Despesas</span><strong>{BRL.format(despesas)}</strong>
        </div>
        <div className="bg-gray-50 rounded-2xl p-3 flex items-center justify-between">
          <span>Lucro Oper.</span><strong>{BRL.format(lucroOperacional)}</strong>
        </div>
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={porMes} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
            <XAxis dataKey="mes" fontSize={12}/>
            <YAxis fontSize={12}/>
            <Tooltip formatter={(v)=>BRL.format(v)} />
            <Area type="monotone" dataKey="receita" fillOpacity={0.3} strokeOpacity={0.8} />
            <Area type="monotone" dataKey="saida" fillOpacity={0.3} strokeOpacity={0.8} />
            <Area type="monotone" dataKey="saldo" fillOpacity={0.3} strokeOpacity={0.8} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Section>
  );
}

/***** BACKUP IMPORT/EXPORT *****/
function BackupControls({ db, dispatch }) {
  const exportDB = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `solaya_finance_${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  };
  const importDB = async () => {
    const input = document.createElement("input");
    input.type = "file"; input.accept = ".json";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      const text = await file.text();
      try { dispatch({ type: "LOAD", payload: JSON.parse(text) }); } catch { alert("Arquivo inválido"); }
    };
    input.click();
  };

  return (
    <div className="flex flex-wrap gap-2">
      <Button onClick={exportDB}><Download size={16}/> Exportar</Button>
      <Button variant="outline" onClick={importDB}><Upload size={16}/> Importar</Button>
      <Button variant="danger" onClick={()=>{
        if (confirm("Resetar banco de dados local?")) dispatch({ type: "RESET" });
      }}>Resetar</Button>
    </div>
  );
}

/***** NAV *****/
const NAV = [
  { key: "dashboard", label: "Dashboard", icon: <ChevronRight size={16}/> },
  { key: "transactions", label: "Lançamentos", icon: <FolderOpen size={16}/> },
  { key: "fixed", label: "Gastos Fixos", icon: <Repeat size={16}/> },
  { key: "investments", label: "Investimentos", icon: <TrendingUp size={16}/> },
  { key: "suppliers", label: "Fornecedores", icon: <Factory size={16}/> },
  { key: "collaborators", label: "Colaboradores", icon: <Users size={16}/> },
  { key: "categories", label: "Categorias", icon: <ClipboardList size={16}/> },
  { key: "accounts", label: "Contas/Carteiras", icon: <Wallet size={16}/> },
  { key: "reports", label: "Relatórios", icon: <BarChart3 size={16}/> },
  { key: "backup", label: "Backup", icon: <Settings size={16}/> },
];

/***** APP *****/
export default function App() {
  const { state: db, dispatch } = useDB();
  const [tab, setTab] = useState("dashboard");

  // Auto-lançamento de Gastos Fixos do mês (idempotente por mês)
  useEffect(()=>{
    const monthKey = `fx_run_${new Date().toISOString().slice(0,7)}`;
    if (localStorage.getItem(monthKey)) return;
    const todayNum = new Date().getDate();
    const items = db.fixedExpenses.filter(f=> f.active !== false && Number(f.day) <= todayNum).map(f=>({
      id: uid(), date: today(), type: "saida", amount: f.amount, categoryId: f.categoryId, accountId: f.accountId, description: `Fixo: ${f.name}`, status: "confirmado"
    }));
    if (items.length) {
      dispatch({ type: "BULK_INSERT", collection: "transactions", items });
      localStorage.setItem(monthKey, "1");
    }
    // eslint-disable-next-line
  },[]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-rose-50 p-5">
      <header className="max-w-7xl mx-auto flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-black text-white grid place-items-center font-bold">S</div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">SOLAYA • Sistema Financeiro</h1>
            <p className="text-gray-500 text-sm">MVP local — pronto para testes e validação</p>
          </div>
        </div>
        <BackupControls db={db} dispatch={dispatch} />
      </header>

      <main className="max-w-7xl mx-auto grid lg:grid-cols-[260px_1fr] gap-5">
        <nav className="bg-white/80 backdrop-blur border border-gray-100 rounded-2xl p-3 h-max">
          <ul className="space-y-1">
            {NAV.map((n)=> (
              <li key={n.key}>
                <button onClick={()=> setTab(n.key)} className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-left hover:bg-gray-100 ${tab===n.key? "bg-gray-900 text-white hover:bg-gray-900": ""}`}>
                  {n.icon}
                  <span>{n.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="space-y-5">
          {tab === "dashboard" && <Dashboard db={db} />}
          {tab === "transactions" && <TransactionsModule db={db} dispatch={dispatch} />}

          {tab === "fixed" && (
            <SimpleModule
              title="Gastos Fixos"
              collection="fixedExpenses"
              icon={<Repeat size={18}/>}
              db={db}
              dispatch={dispatch}
              fields={[
                { key: "name", label: "Nome" },
                { key: "day", label: "Dia Venc.", inputType: "number" },
                { key: "amount", label: "Valor", inputType: "number" },
                { key: "accountId", label: "Conta", type: "select", options: db.accounts.map(a=>({ value:a.id, label:a.name })) },
                { key: "categoryId", label: "Categoria", type: "select", options: db.categories.filter(c=>c.kind==="saida").map(c=>({ value:c.id, label:c.name })) },
                { key: "active", label: "Ativo (true/false)" },
              ]}
            />
          )}

          {tab === "investments" && (
            <SimpleModule
              title="Investimentos"
              collection="investments"
              icon={<TrendingUp size={18}/>}
              db={db}
              dispatch={dispatch}
              fields={[
                { key: "date", label: "Data" },
                { key: "name", label: "Nome" },
                { key: "amount", label: "Valor", inputType: "number" },
                { key: "accountId", label: "Conta", type: "select", options: db.accounts.map(a=>({ value:a.id, label:a.name })) },
                { key: "categoryId", label: "Categoria", type: "select", options: db.categories.filter(c=>c.kind==="investimento").map(c=>({ value:c.id, label:c.name })) },
                { key: "notes", label: "Notas" },
              ]}
            />
          )}

          {tab === "suppliers" && (
            <SimpleModule
              title="Fornecedores"
              collection="suppliers"
              icon={<Factory size={18}/>}
              db={db}
              dispatch={dispatch}
              fields={[
                { key: "name", label: "Nome" },
                { key: "email", label: "E-mail" },
                { key: "phone", label: "Telefone" },
                { key: "notes", label: "Notas" },
              ]}
            />
          )}

          {tab === "collaborators" && (
            <SimpleModule
              title="Colaboradores"
              collection="collaborators"
              icon={<Users size={18}/>}
              db={db}
              dispatch={dispatch}
              fields={[
                { key: "name", label: "Nome" },
                { key: "role", label: "Função" },
                { key: "share", label: "% do Job (ex.: 60)", inputType: "number" },
                { key: "pix", label: "PIX" },
              ]}
            />
          )}

          {tab === "categories" && (
            <SimpleModule
              title="Categorias"
              collection="categories"
              icon={<ClipboardList size={18}/>}
              db={db}
              dispatch={dispatch}
              fields={[
                { key: "name", label: "Nome" },
                { key: "kind", label: "Tipo", type: "select", options: [
                  { value:"entrada", label:"Entrada" },
                  { value:"saida", label:"Saída" },
                  { value:"investimento", label:"Investimento" },
                ]},
              ]}
            />
          )}

          {tab === "accounts" && (
            <SimpleModule
              title="Contas/Carteiras"
              collection="accounts"
              icon={<Wallet size={18}/>}
              db={db}
              dispatch={dispatch}
              fields={[
                { key: "name", label: "Nome" },
                { key: "type", label: "Tipo", type: "select", options: [
                  { value:"caixa", label:"Caixa" },
                  { value:"bancaria", label:"Bancária" },
                  { value:"cartao", label:"Cartão" },
                  { value:"outro", label:"Outro" },
                ]},
              ]}
            />
          )}

          {tab === "reports" && <Reports db={db} />}
          {tab === "backup" && (
            <Section title="Backup & Dados" icon={<Settings size={18}/> }>
              <p className="text-sm text-gray-600 mb-3">Exporte/importe todos os dados. Útil para migrar para um backend real (Supabase/Firebase/Postgres) depois do MVP.</p>
              <BackupControls db={db} dispatch={dispatch} />
              <div className="mt-4">
                <pre className="bg-gray-50 p-3 rounded-2xl overflow-auto text-xs">{JSON.stringify(db, null, 2)}</pre>
              </div>
            </Section>
          )}
        </div>
      </main>

      <footer className="max-w-7xl mx-auto mt-8 text-center text-xs text-gray-500">
        SOLAYA © {new Date().getFullYear()} • MVP local • Feito para validação rápida.
      </footer>
    </div>
  );
}
